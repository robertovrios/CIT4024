﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/28/2020
 * This program calculates dorm, meal, and total cost from a list
 */

namespace Program9_6
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //Initialize Class Variables
        string selectedDorm, selectedMeal;
        int dormPrice = 0, mealPrice = 0;

        //Initialize Dorm Data array
        string[,] dormData = new string[,] { {"Allan Hall", "1500"},
            {"Pike Hall", "1600"}, {"Farthing Hall", "1800"}, {"University Suites", "2500"}
        };

        //Initialize Meal Data array
        string[,] mealData = new string[,] { {"7 meals per week", "600"},
            {"14 meals per week", "1200"}, {"Unlimited meals", "1700"}
        };

        //Upon form load, initialize list boxes with data coorisponding to array data
        private void Form1_Load(object sender, EventArgs e)
        {
            dormListBox.Items.Add("Allan Hall");
            dormListBox.Items.Add("Pike Hall");
            dormListBox.Items.Add("Farthing Hall");
            dormListBox.Items.Add("University Suites");

            mealListBox.Items.Add("7 meals per week");
            mealListBox.Items.Add("14 meals per week");
            mealListBox.Items.Add("Unlimited meals");
        }

        //Load dorm data from array element when dorm is selected from dorm list box
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedDorm = dormListBox.SelectedItem.ToString();
            for (int i = 0; i < dormListBox.Items.Count; i++)
            {
                if (dormData[i, 0] == selectedDorm)
                {
                    dormPrice = int.Parse(dormData[i, 1]);
                    break;
                }
            }
        }

        //Load meal data from array element when meal plan is selected from meal list box
        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedMeal = mealListBox.SelectedItem.ToString();
            for (int i = 0; i < mealListBox.Items.Count; i++)
            {
                if (mealData[i, 0] == selectedMeal)
                {
                    mealPrice = int.Parse(mealData[i, 1]);
                    break;
                }
            }
        }

        //Process Display Button
        private void displayButton_Click(object sender, EventArgs e)
        {
            DormSummary formulario = new DormSummary();

            formulario.lblDormCost.Text = dormPrice.ToString("c2");
            formulario.lblMealCost.Text = mealPrice.ToString("c2");
            formulario.lblTotalCost.Text = (dormPrice + mealPrice).ToString("c2");

            formulario.ShowDialog();


        }

    }
}
