﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Program9_2
{
    // class
    class Car
    {
        private int _year;
        private string _make;
        private string _model;
        private int _speed;
        
        // constructor
        public Car(int year, string make, string model)
        {
            _year = year;
            _make = make;
            _model = model;
            _speed = 0;

        }

        // constructor
        public Car(string make, string model)
        {
            _year = 2000;
            _make = make;
            _model = model;
            _speed = 0;
        }

        // Year property
        public int Year
        {
            get { return _year; }
            set { _year = value; }
        }

        // make property
        public string Make
        {
            get { return _make; }
            set { _make = value; }
        }

        // model property
        public string Model
        {
            get { return _model; }
            set { _model = value; }
        }
        // speed property
        public int Speed
        {
            get { return _speed; }
            set { _speed = value; }
        }

        // method accelerate
        public void Accelerate(int val)
        {            
                _speed += val;
        }

        // method brake 
        public void Brake(int val)
        {
            if (_speed >= val)
                _speed -= val;
        }
    }
}
