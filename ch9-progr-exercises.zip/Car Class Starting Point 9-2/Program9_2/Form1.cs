﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/28/2020
 * This program instances a Car class and calls its 2 methods
 */
namespace Program9_2
{
    public partial class Form1 : Form
    {
        // create 2 constants
        const int ACCELERATION = 5;
        const int BRAKE = 5;
        // create 2 instance of car class
        Car myCar = new Car(2015, "Ford", "Taurus");  //Testing the constructor with three arugements

        //Car myCar = new Car("Ford", "Taurus");  //Testing the constructor with two arugments



        public Form1()
        {
            InitializeComponent();
        }

        private void btn_Accelerate_Click(object sender, EventArgs e)
        {
            // call the accelerate method
            myCar.Accelerate(ACCELERATION);
            // print results
            lbl_Display.Text = myCar.Year.ToString()+" "+myCar.Make+" "+myCar.Model+" is moving at " + myCar.Speed.ToString("n") + " Miles per hour";
        }

        private void btn_Brake_Click(object sender, EventArgs e)
        {
            // call the brake method 
            myCar.Brake(BRAKE);
            // print results

            lbl_Display.Text = myCar.Year.ToString() + " " + myCar.Make + " " + myCar.Model + " is braking at " + myCar.Speed.ToString("n") + " Miles per hour";


            
        }

    }
}
