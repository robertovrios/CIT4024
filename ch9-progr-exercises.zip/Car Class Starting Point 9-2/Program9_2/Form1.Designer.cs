﻿namespace Program9_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_Display = new System.Windows.Forms.Label();
            this.btn_Accelerate = new System.Windows.Forms.Button();
            this.btn_Brake = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbl_Display
            // 
            this.lbl_Display.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_Display.Location = new System.Drawing.Point(19, 20);
            this.lbl_Display.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lbl_Display.Name = "lbl_Display";
            this.lbl_Display.Size = new System.Drawing.Size(388, 34);
            this.lbl_Display.TabIndex = 0;
            this.lbl_Display.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btn_Accelerate
            // 
            this.btn_Accelerate.Location = new System.Drawing.Point(99, 60);
            this.btn_Accelerate.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Accelerate.Name = "btn_Accelerate";
            this.btn_Accelerate.Size = new System.Drawing.Size(112, 35);
            this.btn_Accelerate.TabIndex = 1;
            this.btn_Accelerate.Text = "Accelerate";
            this.btn_Accelerate.UseVisualStyleBackColor = true;
            this.btn_Accelerate.Click += new System.EventHandler(this.btn_Accelerate_Click);
            // 
            // btn_Brake
            // 
            this.btn_Brake.Location = new System.Drawing.Point(220, 60);
            this.btn_Brake.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_Brake.Name = "btn_Brake";
            this.btn_Brake.Size = new System.Drawing.Size(112, 35);
            this.btn_Brake.TabIndex = 2;
            this.btn_Brake.Text = "Brake";
            this.btn_Brake.UseVisualStyleBackColor = true;
            this.btn_Brake.Click += new System.EventHandler(this.btn_Brake_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(426, 114);
            this.Controls.Add(this.btn_Brake);
            this.Controls.Add(this.btn_Accelerate);
            this.Controls.Add(this.lbl_Display);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Car Class Program";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lbl_Display;
        private System.Windows.Forms.Button btn_Accelerate;
        private System.Windows.Forms.Button btn_Brake;
    }
}

