﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/28/2020
 * This program creates a class Pet to stores 3 properties or characteristic and display these values in another window
 * */

namespace PetClass
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        //method that prints class values 
        private void printData(Pet mascota)
        {
            // create a Form class instance and assign values to the label properties 
            Results resultado = new Results();
            resultado.lblName.Text = mascota.Name;
            resultado.lblType.Text = mascota.Type;
            resultado.lblAge.Text = mascota.Age.ToString();

            // display results
            resultado.ShowDialog();

        }
        private void btnEnterData_Click(object sender, EventArgs e)
        {
            // create an instance of Pet and construct the object
            Pet mascota = new Pet();
            mascota.Name = txtName.Text;
            mascota.Type = txtType.Text;
            // test integer validation
            if (int.TryParse(txtAge.Text, out int age))
            {
                mascota.Age = age;
                // call method to print data
                printData(mascota);
            }
            else
            {
                MessageBox.Show("Enter a valid number for age");
            }


        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
