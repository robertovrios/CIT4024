﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


/* Roberto Vasquez
 * 1/25/2020
 * This program gets user price and discount and calculates 
 * the sale price
 */
namespace SalePriceCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {


            try
            {

                decimal originalPrice; // the item's original price
                decimal discountPercentage; // the discount percentage
                 //decimal discountAmount; // The amount of discount
                decimal salePrice; // The item's sale Price

                if (decimal.Parse(discountPercentageTextBox.Text) >= 0
                    && decimal.Parse(originalPriceTextBox.Text) >= 0)
                {
                    // Get the item's original price.
                    originalPrice = decimal.Parse(originalPriceTextBox.Text);
                    // Get the discount percentage and move 2 decimals
                    discountPercentage = decimal.Parse(discountPercentageTextBox.Text) / 100;

                    // Calculate the amount of the discount.
                    //discountAmount = originalPrice * discountPercentage;

                    //Calculate the sale price
                    salePrice = originalPrice - originalPrice * discountPercentage;

                    // Display the sale Price
                    salePriceLabel.Text = salePrice.ToString("c");
                }
                else
                {
                    MessageBox.Show("Please enter a number >=0");
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                MessageBox.Show("Please enter numeric value in the Boxes!!");

            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();

        }
    }
}
