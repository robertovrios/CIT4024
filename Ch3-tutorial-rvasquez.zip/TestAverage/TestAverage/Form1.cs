﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 1/25/2020
 * This program calculates the average test of 3 input tests
 */

namespace TestAverage
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // create the variables
                double test1,
                    test2,
                    test3,
                    average;

                // assign values from the textboxes to the variables
                test1 = double.Parse(test1TextBox.Text);
                test2 = double.Parse(test2TextBox.Text);
                test3 = double.Parse(test3TextBox.Text);

                // calculate the average
                average = (test1 + test2 + test3) / 3;

                // Display the results
                averageLabel.Text = average.ToString("n1");

            }
            catch (Exception ex)
            {
                // show the exception message
                MessageBox.Show(ex.Message);
            }

        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // clear the textboxes and focus to the 1st textbox
            test1TextBox.Text = "";
            test2TextBox.Text = "";
            test3TextBox.Text = "";
            averageLabel.Text = "";
            test1TextBox.Focus();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // close the program
            this.Close();
        }
    }
}
