﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/21/2020
 * This program calculates a invoice for an automotive
 */

namespace JoesAutomotive
{
    public partial class Form1 : Form
    {
        // define constant variables
        const decimal CHANGE_OIL_COST= 26.00m;
        const decimal LUBE_JOB_COST = 18.00m;
        const decimal RADIATOR_FLUSH_COST = 30.00m;
        const decimal TRANS_FLUSH_COST = 80.00m;
        const decimal INSPECTION_COST = 15.00m;
        const decimal REPLACE_MUFFLER_COST = 100.00m;
        const decimal TIRE_ROTATION_COST = 20.00m;
        const decimal LABOR_CHARGES = 20.00m;

        public Form1()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void ClearOilLube()
        {
            cboxOilChange.Checked = false;
            cboxLubeJob.Checked = false;
        }

        private void ClearFlushes()
        {
            cboxTransFlush.Checked = false;
            cboxRadiatorFlush.Checked = false;
        }

        private void ClearMisc()
        {
            cboxInspection.Checked = false;
            cboxReplaceMu.Checked = false;
            cboxTireRot.Checked = false;
        }

        private void ClearOther()
        {
            lblParts.Text = null;
            lblServLabor.Text = null;
        }

        private void ClearFees()
        {

            lblTax.Text = null;
            lblTotalFees.Text = null;
        }
        private void ClearLaborAndParts()
        {
            txtLabor.Clear();
            txtParts.Clear();
        }
        
        private void btnClear_Click(object sender, EventArgs e)
        {
            // clear all textboxes, checkboxes, and labels
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
            ClearLaborAndParts();
        }


        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // create an array with constant values
            decimal[] costs = { CHANGE_OIL_COST,
                            LUBE_JOB_COST,
                            RADIATOR_FLUSH_COST,
                            TRANS_FLUSH_COST,
                            INSPECTION_COST,
                            REPLACE_MUFFLER_COST,
                            TIRE_ROTATION_COST};

            // create an array with the checkboxes boolean values. Assign "1" when checkbox is checked or "0" is unchecked.
            int[] order = {(cboxOilChange.Checked)? 1:0,
                            (cboxLubeJob.Checked) ? 1 : 0,
                            (cboxRadiatorFlush.Checked)? 1:0,
                            (cboxTransFlush.Checked) ? 1 : 0,
                            (cboxInspection.Checked) ? 1 : 0,
                            (cboxReplaceMu.Checked) ? 1 : 0,
                            (cboxTireRot.Checked) ? 1 : 0};

            decimal labor = 0;
            decimal service = 0;
            decimal parts = 0;
            decimal taxes = 0;
            decimal totalfees = 0;

            // calculate labor
            if (double.TryParse(txtLabor.Text, out double labor_hours))
            {
                labor = calculateLabor(labor_hours);
            }

            // calculate services and print on the textbox
            service = calculateService(costs, order) + labor;
            lblServLabor.Text = service.ToString("c2");

            
            // calculate taxes
            if (decimal.TryParse(txtParts.Text, out parts))
            {
                taxes = calculateTaxes(parts);
            }
            lblTax.Text = taxes.ToString("c2");

            // calculate total fees
            totalfees = labor + service + parts + taxes;

            lblTotalFees.Text = totalfees.ToString("c2");
        }

        private decimal calculateLabor(double labor_hours)
        {
            decimal labor = 0;

                if (labor_hours >= 0)
                    labor = (decimal)labor_hours * 20;
            
            return labor;
        }

        private decimal calculateTaxes(decimal parts)
        {
            decimal taxes = 0;
            if (parts >= 0)
                lblParts.Text = parts.ToString("c2");
            taxes = parts * (decimal)0.06;
            return taxes;
            
        }

        private decimal calculateService(decimal[] costs, int[] order)
        {
            decimal total = 0;
            for(int i = 0; i < costs.Length; i++)
            {
                total+=costs[i] * order[i];
            }

            return total;
        }
    }
}
