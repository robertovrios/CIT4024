﻿namespace JoesAutomotive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.cboxOilChange = new System.Windows.Forms.CheckBox();
            this.cboxLubeJob = new System.Windows.Forms.CheckBox();
            this.cboxRadiatorFlush = new System.Windows.Forms.CheckBox();
            this.cboxTransFlush = new System.Windows.Forms.CheckBox();
            this.cboxInspection = new System.Windows.Forms.CheckBox();
            this.cboxReplaceMu = new System.Windows.Forms.CheckBox();
            this.cboxTireRot = new System.Windows.Forms.CheckBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtParts = new System.Windows.Forms.TextBox();
            this.txtLabor = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.lblServLabor = new System.Windows.Forms.Label();
            this.lblParts = new System.Windows.Forms.Label();
            this.lblTax = new System.Windows.Forms.Label();
            this.lblTotalFees = new System.Windows.Forms.Label();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.Exit = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cboxLubeJob);
            this.groupBox1.Controls.Add(this.cboxOilChange);
            this.groupBox1.Location = new System.Drawing.Point(30, 47);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(297, 129);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Oil and Lube";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.cboxTransFlush);
            this.groupBox2.Controls.Add(this.cboxRadiatorFlush);
            this.groupBox2.Location = new System.Drawing.Point(347, 47);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(351, 129);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Rushes";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cboxTireRot);
            this.groupBox3.Controls.Add(this.cboxReplaceMu);
            this.groupBox3.Controls.Add(this.cboxInspection);
            this.groupBox3.Location = new System.Drawing.Point(30, 192);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(297, 176);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Misc";
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.txtLabor);
            this.groupBox4.Controls.Add(this.txtParts);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Location = new System.Drawing.Point(347, 192);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(351, 176);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Parts and Labor";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lblTotalFees);
            this.groupBox5.Controls.Add(this.lblTax);
            this.groupBox5.Controls.Add(this.lblParts);
            this.groupBox5.Controls.Add(this.lblServLabor);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Location = new System.Drawing.Point(30, 391);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(668, 230);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Summary";
            // 
            // cboxOilChange
            // 
            this.cboxOilChange.AutoSize = true;
            this.cboxOilChange.Location = new System.Drawing.Point(22, 42);
            this.cboxOilChange.Name = "cboxOilChange";
            this.cboxOilChange.Size = new System.Drawing.Size(176, 24);
            this.cboxOilChange.TabIndex = 0;
            this.cboxOilChange.Text = "Oil Change ($26.00)";
            this.cboxOilChange.UseVisualStyleBackColor = true;
            // 
            // cboxLubeJob
            // 
            this.cboxLubeJob.AutoSize = true;
            this.cboxLubeJob.Location = new System.Drawing.Point(22, 81);
            this.cboxLubeJob.Name = "cboxLubeJob";
            this.cboxLubeJob.Size = new System.Drawing.Size(164, 24);
            this.cboxLubeJob.TabIndex = 1;
            this.cboxLubeJob.Text = "Lube Job ($18.00)";
            this.cboxLubeJob.UseVisualStyleBackColor = true;
            // 
            // cboxRadiatorFlush
            // 
            this.cboxRadiatorFlush.AutoSize = true;
            this.cboxRadiatorFlush.Location = new System.Drawing.Point(22, 42);
            this.cboxRadiatorFlush.Name = "cboxRadiatorFlush";
            this.cboxRadiatorFlush.Size = new System.Drawing.Size(202, 24);
            this.cboxRadiatorFlush.TabIndex = 0;
            this.cboxRadiatorFlush.Text = "Radiator Flush ($30.00)";
            this.cboxRadiatorFlush.UseVisualStyleBackColor = true;
            // 
            // cboxTransFlush
            // 
            this.cboxTransFlush.AutoSize = true;
            this.cboxTransFlush.Location = new System.Drawing.Point(22, 81);
            this.cboxTransFlush.Name = "cboxTransFlush";
            this.cboxTransFlush.Size = new System.Drawing.Size(234, 24);
            this.cboxTransFlush.TabIndex = 1;
            this.cboxTransFlush.Text = "Transmission Flush ($80.00)";
            this.cboxTransFlush.UseVisualStyleBackColor = true;
            // 
            // cboxInspection
            // 
            this.cboxInspection.AutoSize = true;
            this.cboxInspection.Location = new System.Drawing.Point(22, 34);
            this.cboxInspection.Name = "cboxInspection";
            this.cboxInspection.Size = new System.Drawing.Size(172, 24);
            this.cboxInspection.TabIndex = 0;
            this.cboxInspection.Text = "Inspection ($15.00)";
            this.cboxInspection.UseVisualStyleBackColor = true;
            // 
            // cboxReplaceMu
            // 
            this.cboxReplaceMu.AutoSize = true;
            this.cboxReplaceMu.Location = new System.Drawing.Point(22, 74);
            this.cboxReplaceMu.Name = "cboxReplaceMu";
            this.cboxReplaceMu.Size = new System.Drawing.Size(219, 24);
            this.cboxReplaceMu.TabIndex = 1;
            this.cboxReplaceMu.Text = "Replace Muffler ($100.00)";
            this.cboxReplaceMu.UseVisualStyleBackColor = true;
            // 
            // cboxTireRot
            // 
            this.cboxTireRot.AutoSize = true;
            this.cboxTireRot.Location = new System.Drawing.Point(22, 115);
            this.cboxTireRot.Name = "cboxTireRot";
            this.cboxTireRot.Size = new System.Drawing.Size(189, 24);
            this.cboxTireRot.TabIndex = 2;
            this.cboxTireRot.Text = "Tire Rotation ($20.00)";
            this.cboxTireRot.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(55, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Parts";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(28, 87);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Labor ($)";
            // 
            // txtParts
            // 
            this.txtParts.Location = new System.Drawing.Point(140, 38);
            this.txtParts.Name = "txtParts";
            this.txtParts.Size = new System.Drawing.Size(100, 26);
            this.txtParts.TabIndex = 2;
            // 
            // txtLabor
            // 
            this.txtLabor.Location = new System.Drawing.Point(140, 87);
            this.txtLabor.Name = "txtLabor";
            this.txtLabor.Size = new System.Drawing.Size(100, 26);
            this.txtLabor.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(18, 51);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(137, 20);
            this.label3.TabIndex = 0;
            this.label3.Text = "Service and Labor";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(109, 87);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(46, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Parts";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(49, 123);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(106, 20);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tax (on parts)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(71, 159);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(84, 20);
            this.label6.TabIndex = 3;
            this.label6.Text = "Total Fees";
            // 
            // lblServLabor
            // 
            this.lblServLabor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblServLabor.Location = new System.Drawing.Point(204, 51);
            this.lblServLabor.Name = "lblServLabor";
            this.lblServLabor.Size = new System.Drawing.Size(172, 34);
            this.lblServLabor.TabIndex = 4;
            // 
            // lblParts
            // 
            this.lblParts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblParts.Location = new System.Drawing.Point(204, 87);
            this.lblParts.Name = "lblParts";
            this.lblParts.Size = new System.Drawing.Size(172, 34);
            this.lblParts.TabIndex = 5;
            // 
            // lblTax
            // 
            this.lblTax.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTax.Location = new System.Drawing.Point(204, 123);
            this.lblTax.Name = "lblTax";
            this.lblTax.Size = new System.Drawing.Size(172, 34);
            this.lblTax.TabIndex = 6;
            // 
            // lblTotalFees
            // 
            this.lblTotalFees.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblTotalFees.Location = new System.Drawing.Point(204, 159);
            this.lblTotalFees.Name = "lblTotalFees";
            this.lblTotalFees.Size = new System.Drawing.Size(172, 34);
            this.lblTotalFees.TabIndex = 7;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(72, 641);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(145, 44);
            this.btnCalculate.TabIndex = 5;
            this.btnCalculate.Text = "C&alculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // btnClear
            // 
            this.btnClear.Location = new System.Drawing.Point(292, 641);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(145, 44);
            this.btnClear.TabIndex = 6;
            this.btnClear.Text = "C&lear";
            this.btnClear.UseVisualStyleBackColor = true;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);
            // 
            // Exit
            // 
            this.Exit.Location = new System.Drawing.Point(512, 641);
            this.Exit.Name = "Exit";
            this.Exit.Size = new System.Drawing.Size(145, 44);
            this.Exit.TabIndex = 7;
            this.Exit.Text = "E&xit";
            this.Exit.UseVisualStyleBackColor = true;
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 727);
            this.Controls.Add(this.Exit);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnCalculate);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Automotive";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cboxLubeJob;
        private System.Windows.Forms.CheckBox cboxOilChange;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox cboxTransFlush;
        private System.Windows.Forms.CheckBox cboxRadiatorFlush;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox cboxTireRot;
        private System.Windows.Forms.CheckBox cboxReplaceMu;
        private System.Windows.Forms.CheckBox cboxInspection;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox txtLabor;
        private System.Windows.Forms.TextBox txtParts;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lblTotalFees;
        private System.Windows.Forms.Label lblTax;
        private System.Windows.Forms.Label lblParts;
        private System.Windows.Forms.Label lblServLabor;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button Exit;
    }
}

