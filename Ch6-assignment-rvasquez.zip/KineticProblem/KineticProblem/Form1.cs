﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


/* Roberto Vasquez
 * 2/21/2020
 * This program calculates the kinetic energy of an object using its mass and velocity
 */

namespace KineticProblem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method that calculates the kinetic energy
        private double calculaEnergia(double mass, double speed)
        {
            if (speed >= 0 && mass >= 0)
            {
                return 0.5 * mass * speed * speed;
            }
            else
            {
                return -1;
            }
        }

        
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // make white text boxes
            txtMass.BackColor = Color.White;
            txtVelocity.BackColor = Color.White;
            try
            {
               // valid input data to be numbers

                if (double.TryParse(txtMass.Text, out double mass) && double.TryParse(txtVelocity.Text, out double speed))
                {
                    if (calculaEnergia(mass, speed) != -1)
                    {
                        lblResults.Text = calculaEnergia(mass, speed).ToString("n2");
                    }
                    else
                    {
                        ErrorMessages(-1);
                    }
                }
                else
                {
                    // error message invalid data
                    if (!double.TryParse(txtMass.Text, out mass))
                    {
                        ErrorMessages(-2);
                    }
                    else
                    {
                        ErrorMessages(-3);
                    }

                }

            }catch(Exception ex)
            {
                // generic exception
                MessageBox.Show(ex.Message);
            }
        }

        // method to show personalized error messages
        private void ErrorMessages(int val)
        {
            switch (val)
            {
                case -1:
                    MessageBox.Show("Enter positive values");
                    break;
                case -2:
                    MessageBox.Show("Enter a number for mass");
                    txtMass.BackColor = Color.Red;
                    txtMass.Focus();

                    break;
                case -3:
                    MessageBox.Show("Enter a number for velocity");
                    txtVelocity.BackColor = Color.Red;
                    txtVelocity.Focus();


                    break;
                default:
                    break;
            }

        }

    }
}
