﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/22/2020
 * This program shows if a number is prime or is not prime.
 */


namespace PrimeNumbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnPrime_Click(object sender, EventArgs e)
        {
            // string output variable
            String isPrime= "Prime";
            
            // valid number is integer and greater than 0
            if (int.TryParse(txtNumber.Text,out int numero)&& numero>0){

                // demostrate that number is not prime
                for (int i = 2; i < numero; i++)
                {
                    if (numero % i == 0)
                    {
                        isPrime= "not Prime";
                        break;
                    }
                    
                }

                // show results
                lblResults.Text = "The number " + numero + " is " + isPrime+".";
            }
            else
            {
                // error message for invalid input
                MessageBox.Show("Enter a valid integer number greater than zero.");
                txtNumber.Focus();
                txtNumber.BackColor = Color.Pink;
            }
        }

    }
}
