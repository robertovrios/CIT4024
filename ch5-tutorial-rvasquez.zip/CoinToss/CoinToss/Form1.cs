﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/8/2020
 * This program tosses a coin and shows the result
 */

namespace CoinToss
{
    public partial class Form1 : Form
    {
        // declare a counter to play 10 times
        int count;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnToss_Click(object sender, EventArgs e)
        {
            // increment the counter everytime that user click on button
            count++;
            // create a random number
            Random r = new Random();

            // choose one 2 values for the random number
            
            if (r.Next(2) == 0)
            {
                // if the random number is 0, shows the image coin tail in the results picture box
                picResult.Image = picTail.Image;
                picResult.SizeMode = PictureBoxSizeMode.Zoom;
                picResult.Visible = true;
                // make invisible the others pictures boxes
                picTail.Visible = false;
                picHead.Visible = false;

            }
            else
            {
                // if the random number is 1, shows the image coin head in the results picture box
                picResult.Image = picHead.Image;
                picResult.SizeMode = PictureBoxSizeMode.Zoom;
                picResult.Visible = true;

                // make invisible the others pictures boxes
                picHead.Visible = false;
                picTail.Visible = false;
            }

            // controling your gaming, if users play more than 10 times the system warning you that you're playing too much
            if (count > 10)
            {
                picResult.Visible = false;
                picHead.Visible = true;
                picTail.Visible = true;
                count = 0;
                // ask user to keep playing ot stop 
                if (MessageBox.Show("Do you want to keep playing?","Gamer Attention!!!",MessageBoxButtons.YesNo)==DialogResult.No)
                {
                    this.Close();
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
