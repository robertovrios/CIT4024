﻿namespace CoinToss
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picHead = new System.Windows.Forms.PictureBox();
            this.picTail = new System.Windows.Forms.PictureBox();
            this.btnToss = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.picResult = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picHead)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).BeginInit();
            this.SuspendLayout();
            // 
            // picHead
            // 
            this.picHead.Image = global::CoinToss.Properties.Resources.Heads1;
            this.picHead.Location = new System.Drawing.Point(51, 68);
            this.picHead.Name = "picHead";
            this.picHead.Size = new System.Drawing.Size(170, 170);
            this.picHead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picHead.TabIndex = 0;
            this.picHead.TabStop = false;
            // 
            // picTail
            // 
            this.picTail.Image = global::CoinToss.Properties.Resources.Tails1;
            this.picTail.Location = new System.Drawing.Point(278, 68);
            this.picTail.Name = "picTail";
            this.picTail.Size = new System.Drawing.Size(170, 170);
            this.picTail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picTail.TabIndex = 1;
            this.picTail.TabStop = false;
            // 
            // btnToss
            // 
            this.btnToss.Location = new System.Drawing.Point(104, 285);
            this.btnToss.Name = "btnToss";
            this.btnToss.Size = new System.Drawing.Size(100, 61);
            this.btnToss.TabIndex = 2;
            this.btnToss.Text = "T&oss";
            this.btnToss.UseVisualStyleBackColor = true;
            this.btnToss.Click += new System.EventHandler(this.btnToss_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(278, 285);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(100, 61);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // picResult
            // 
            this.picResult.Location = new System.Drawing.Point(118, 47);
            this.picResult.Name = "picResult";
            this.picResult.Size = new System.Drawing.Size(235, 216);
            this.picResult.TabIndex = 4;
            this.picResult.TabStop = false;
            this.picResult.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(529, 450);
            this.Controls.Add(this.picResult);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnToss);
            this.Controls.Add(this.picTail);
            this.Controls.Add(this.picHead);
            this.Name = "Form1";
            this.Text = "Coin Toss";
            ((System.ComponentModel.ISupportInitialize)(this.picHead)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picTail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picResult)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picHead;
        private System.Windows.Forms.PictureBox picTail;
        private System.Windows.Forms.Button btnToss;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.PictureBox picResult;
    }
}

