﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

/* Roberto Vasquez
 * 2/8/2020
 * This program creates a file and writes on it 
 */

namespace Friend_File
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void writeNameButton_Click(object sender, EventArgs e)
        {
            try
            {
                // create a object file and write on it
                StreamWriter outputFile;
                outputFile = File.CreateText("Friend.txt");
                outputFile.WriteLine(nameTextBox.Text);
                outputFile.Close();
                MessageBox.Show("The name was written.");

            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
