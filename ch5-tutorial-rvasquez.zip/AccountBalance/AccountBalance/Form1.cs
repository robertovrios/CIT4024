﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


/* Roberto Vasquez
 * 2/8/2020
 * This program calculates the total balance of a loan
 */

namespace AccountBalance
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // clear all backcolors and textboxes
            txtStartBalance.BackColor = Color.White;
            txtNumMonths.BackColor = Color.White;
            lblResults.BackColor = Color.White;
            txtStartBalance.Focus();
            txtStartBalance.Text = "";
            txtNumMonths.Text = "";
            lblResults.Text = "";
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // declare a constant and clear backcolors
            const decimal INTEREST_RATE = 0.005m;
            txtStartBalance.BackColor = Color.White;
            txtNumMonths.BackColor = Color.White;
            lblResults.BackColor = Color.White;

            // test that textbox inputs are valids
            if (decimal.TryParse(txtStartBalance.Text, out decimal balance))
            {

                if (int.TryParse(txtNumMonths.Text, out int months))
                {
                    //calculate the balance after i months
                    for (int i = 1; i <= months; i++)
                    {
                        balance += balance * INTEREST_RATE;
                    }
                    // shows the calculated balance
                    lblResults.Text = balance.ToString("c2");
                }
                else
                {
                    // shows invalid input data error message 
                    lblResults.Text = "Enter a Valid Input";
                    lblResults.BackColor = Color.Pink;
                    txtNumMonths.BackColor = Color.Red;
                    txtNumMonths.Focus();

                }
            }
            else
            {
                // shows invalid input data error message 
                lblResults.Text = "Enter a Valid Input";
                lblResults.BackColor = Color.Pink;
                txtStartBalance.BackColor = Color.Red;
                txtStartBalance.Focus();

            }
        }
    }
}
