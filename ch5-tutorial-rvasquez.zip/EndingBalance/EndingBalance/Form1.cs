﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/8/2020
 * This program calculates the details and total balance of a loan
 */

namespace EndingBalance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // clear all backcolors and textboxes
            txtStartingBalance.BackColor = Color.White;
            txtNumberMonths.BackColor = Color.White;
            lblResults.BackColor = Color.White;
            txtStartingBalance.Focus();
            txtStartingBalance.Text = "";
            txtNumberMonths.Text = "";
            lblResults.Text = "";
            lstDetails.Items.Clear();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {

            // declare a constant and clear backcolors
            const decimal INTEREST_RATE = 0.005m;
            txtStartingBalance.BackColor = Color.White;
            txtNumberMonths.BackColor = Color.White;
            lblResults.BackColor = Color.White;
            lstDetails.Items.Clear();

            // test that textbox inputs are valids
            if (decimal.TryParse(txtStartingBalance.Text, out decimal balance))
            {

                if (int.TryParse(txtNumberMonths.Text, out int months))
                {
                   
                    // calculates all balance details and shows into the listBox
                    for (int i = 1; i <= months; i++)
                    {
                        balance += balance * INTEREST_RATE;
                        lstDetails.Items.Add("The ending balance for month " + i + " is " + balance.ToString("c2"));
                        
                    } 

                    // shows the total balance
                    lblResults.Text = balance.ToString("c2");
                }
                else
                {
                    // shows invalid input data error message 
                    lblResults.Text = "Enter a Valid Input";
                    lblResults.BackColor = Color.Pink;
                    txtNumberMonths.BackColor = Color.Red;
                    txtNumberMonths.Focus();

                }
            }
            else
            {
                // shows invalid input data error message 
                lblResults.Text = "Enter a Valid Input";
                lblResults.BackColor = Color.Pink;
                txtStartingBalance.BackColor = Color.Red;
                txtStartingBalance.Focus();

            }
        }
    }
}
