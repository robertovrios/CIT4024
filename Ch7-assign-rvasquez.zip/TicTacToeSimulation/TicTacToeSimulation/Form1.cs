﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/22/2020
 * This program allow user to play a tic tac toe game
 */



namespace TicTacToeSimulation
{
    public partial class Form1 : Form
    {
        // define a random variable and constants
        const string computer = "O";
        const string man = "X";
        Random rand = new Random();

        // create an global array to save the values 0 - not played yet, 1 - user choice, and 2 - machine choice
        int[,] tablero = new int[3, 3];

        public Form1()
        {
            InitializeComponent();
        }

        // method that permits the program choose a place in the tic tac toe game
        private void MachineChoose()
        {
            
            int end=0;
            bool choosen = false;

            // test if there is available place to play
            for(int i = 0; i < 3; i++)
                for (int j = 0; j < 3; j++)
                {
                    // available place is represented by 0 into the array
                    if (tablero[i, j] == 0) end++;
                }

            // if machine have not choosen a place and there's at least one avalible place, it is the machine's play
            while (!choosen && end>1)
            {
                // random numbers between 0 and 2
                int i = rand.Next(3);
                int j = rand.Next(3);
                
                // test if the position has not been choosen
                if (tablero[i, j] == 0)
                {

                    tablero[i, j] = 2;
                    // choose that place
                    choosen = true;
                    // print O into the label and make it visible;
                    if (i == 0 && j == 0) lbl00.Visible = true;
                    if (i == 0 && j == 0) lbl00.Text = "O";
                    if (i == 0 && j == 1) lbl01.Visible = true;
                    if (i == 0 && j == 1) lbl01.Text = "O";
                    if (i == 0 && j == 2) lbl02.Visible = true;
                    if (i == 0 && j == 2) lbl02.Text = "O";

                    if (i == 1 && j == 0) lbl10.Visible = true;
                    if (i == 1 && j == 0) lbl10.Text = "O";
                    if (i == 1 && j == 1) lbl11.Visible = true;
                    if (i == 1 && j == 1) lbl11.Text = "O";
                    if (i == 1 && j == 2) lbl12.Visible = true;
                    if (i == 1 && j == 2) lbl12.Text = "O";

                    if (i == 2 && j == 0) lbl20.Visible = true;
                    if (i == 2 && j == 0) lbl20.Text = "O";
                    if (i == 2 && j == 1) lbl21.Visible = true;
                    if (i == 2 && j == 1) lbl21.Text = "O";
                    if (i == 2 && j == 2) lbl22.Visible = true;
                    if (i == 2 && j == 2) lbl22.Text = "O";

                    // test if the computer wins. Find all 2's in the array
                    if (WhoWins(2))
                    {
                        MessageBox.Show("Machine Wins");
                    };
                }
            }

            
            
        }

        // method to determine who wins, val = 1 for user and 2 for computer
        private bool WhoWins(int val)
        {
            bool result = false;
            // horizontal
            if (tablero[0, 0] == val && tablero[0, 1] == val && tablero[0, 2] == val) result = true;
            if (tablero[1, 0] == val && tablero[1, 1] == val && tablero[1, 2] == val) result = true;
            if (tablero[2, 0] == val && tablero[2, 1] == val && tablero[2, 2] == val) result = true;
            // vertical
            if (tablero[0, 0] == val && tablero[1, 0] == val && tablero[2, 0] == val) result = true;
            if (tablero[0, 1] == val && tablero[1, 1] == val && tablero[2, 1] == val) result = true;
            if (tablero[0, 2] == val && tablero[1, 2] == val && tablero[2, 2] == val) result = true;
            //cross
            if (tablero[0, 0] == val && tablero[1, 1] == val && tablero[2, 2] == val) result = true;
            if (tablero[0, 2] == val && tablero[1, 1] == val && tablero[2, 0] == val) result = true;


            return result;
        }
        private void btn00_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[0, 0] = 1;
            //
            lbl00.Text = man;
            btn00.Visible = false;
            lbl00.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }


        }

        private void btn01_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[0, 1] = 1;
            
            // put 'X' into the label and make it visible
            lbl01.Text = man;
            btn01.Visible = false;
            lbl01.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn02_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[0, 2] = 1;

            // put 'X' into the label and make it visible
            lbl02.Text = man;
            btn02.Visible = false;
            lbl02.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn10_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[1, 0] = 1;

            // put 'X' into the label and make it visible
            lbl10.Text = man;
            btn10.Visible = false;
            lbl10.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn11_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[1, 1] = 1;

            // put 'X' into the label and make it visible
            lbl11.Text = man;
            btn11.Visible = false;
            lbl11.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn12_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[1, 2] = 1;

            // put 'X' into the label and make it visible
            lbl12.Text = man;
            btn12.Visible = false;
            lbl12.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn20_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[2, 0] = 1;

            // put 'X' into the label and make it visible
            lbl20.Text = man;
            btn20.Visible = false;
            lbl20.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn21_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[2, 1] = 1;

            // put 'X' into the label and make it visible
            lbl21.Text = man;
            btn21.Visible = false;
            lbl21.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btn22_Click(object sender, EventArgs e)
        {
            // put 1 in the array position that represents user play
            tablero[2, 2] = 1;

            // put 'X' into the label and make it visible
            lbl22.Text = man;
            btn22.Visible = false;
            lbl22.Visible = true;

            // test if the user wins. Find all 1's in the array
            if (WhoWins(1))
            {
                MessageBox.Show("User Wins");
            }
            else
            {
                MachineChoose();
            }
        }

        private void btnPlayAgain_Click(object sender, EventArgs e)
        {
            // return to the initial play values
            lbl00.Visible = false;
            lbl01.Visible = false;
            lbl02.Visible = false;
            lbl10.Visible = false;
            lbl11.Visible = false;
            lbl12.Visible = false;
            lbl20.Visible = false;
            lbl21.Visible = false;
            lbl22.Visible = false;

            lbl00.Text = null;
            lbl01.Text = null;
            lbl02.Text = null;
            lbl10.Text = null;
            lbl11.Text = null;
            lbl12.Text = null;
            lbl20.Text = null;
            lbl22.Text = null;
            lbl21.Text = null;

            btn00.Visible = true;
            btn01.Visible = true;
            btn02.Visible = true;
            btn10.Visible = true;
            btn11.Visible = true;
            btn12.Visible = true;
            btn20.Visible = true;
            btn22.Visible = true;
            btn21.Visible = true;

            for(int i = 0; i< 3; i++)
            {
                for (int j = 0; j < 3; j++)
                    tablero[i, j] = 0;
            }

        }
    }
}
