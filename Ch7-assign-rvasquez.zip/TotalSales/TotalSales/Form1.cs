﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;


/* Roberto Vasquez
 * 2/13/2020
 * This program reads a file's content and show it on a list box. Moreover, it calculates the total pushin' a button
 */


namespace TotalSales
{
    public partial class Form1 : Form
    {
        // constant variable path
        const string path = @"../../images/Sales.txt";
        public Form1()
        {
            InitializeComponent();
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method to create an array with size equals to the lines number of the input file
        private decimal[] createArray(string path)
        {
            StreamReader input = File.OpenText(path);
            int size = 0;
            while (!input.EndOfStream)
            {
                size++;
                input.ReadLine();
            }
            input.Close();
            decimal[] sales = new decimal[size];
            return sales;
        }

        // method to fill the array with input file lines
        private decimal[] FillArray(string path, decimal[] sales)
        {
            StreamReader input = File.OpenText(path);
            int i = 0;
            while (!input.EndOfStream)
            {
                sales[i] = decimal.Parse(input.ReadLine());
                i++;
            }
            input.Close();

            return sales;
        }

        // calculate the total using a method
        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal total=calculateTotal();
            
            lblTotal.Text = total.ToString("c2");
        }

        // method that calls 2 methods to create and fill an array. It will look redundant but I prefer to 
        // don't call both methods on the top of the program.
        private decimal calculateTotal()
        {
            decimal total = 0;
            decimal[] sales = createArray(path);
            sales = FillArray(path, sales);
            for (int i = 0; i < sales.Length; i++)
            {
                total += sales[i];
            }
            return total;
        }

        // 
        private void Form1_Load(object sender, EventArgs e)
        {
            try
            {
                // create an array with size equals to number of lines of the input file
                decimal[] sales = createArray(path);

                // fill the array with all lines in the input file
                sales = FillArray(path, sales);

                // add the array values into the list box sales
                for (int i = 0; i < sales.Length; i++)
                    lboxSales.Items.Add(sales[i]);

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
