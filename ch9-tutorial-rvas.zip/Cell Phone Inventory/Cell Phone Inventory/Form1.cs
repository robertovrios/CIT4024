﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/13/2020
 * This program creates a cellphone inventory
 */

namespace Cell_Phone_Inventory
{
    public partial class Form1 : Form
    {
        // create a list phoneList
        List<CellPhone> phoneList = new List<CellPhone>();

        public Form1()
        {
            InitializeComponent();
        }

        // method to create a cellphone class
        private bool CreateCellPhone(CellPhone phone)
        {
            bool result = false;
            phone.Brand = brandTextBox.Text;
            phone.Model = modelTextBox.Text;

            // valid input data
            if (decimal.TryParse(priceTextBox.Text, out decimal price))
            {
                phone.Price = price;
                result = true;
            }
            else
            {
                MessageBox.Show("Please enter a number value");
                priceTextBox.Focus();
                priceTextBox.BackColor = Color.Red;
            }
            return result;
        }


        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void addPhoneButton_Click(object sender, EventArgs e)
        {
            //create a class cellphone
            CellPhone phone = new CellPhone();

            // test the class constructor and add to the listbox
            if (CreateCellPhone(phone))
            {
                phoneListBox.Items.Add(phone.Brand + " " + phone.Model);
                phoneList.Add(phone);
            }

            ClearData();


        }
        // method to clear data
        private void ClearData()
        {
            brandTextBox.Text = null;
            modelTextBox.Text = null;
            priceTextBox.Text = null;

            brandTextBox.Focus();
        }

        // method to show the price of a selected phone from the listbox
        private void phoneListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            int index = phoneListBox.SelectedIndex;

            MessageBox.Show(phoneList[index].Price.ToString("c"));
        }
    }
}
