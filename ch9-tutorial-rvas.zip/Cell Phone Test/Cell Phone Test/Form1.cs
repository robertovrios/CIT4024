﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



/* Roberto Vasquez
 * 2/13/2020
 * This program creates and use a class in order to show data in text boxes
 */

namespace Cell_Phone_Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method that saves data input into an instance of the class phone
        private CellPhone CreateCellPhone(string brand, string model, decimal price)
        {
            CellPhone phone = new CellPhone(brand, model, price);


            return phone;
        }
        private void createObjectButton_Click(object sender, EventArgs e)
        {
            // create a class CellPhone

            // if an instance of the class is created correctly, fills out the labels with user data

            string brand = (brandTextBox.Text == null) ? "" : brandTextBox.Text;
            string model = (modelTextBox.Text == null) ? "" : modelTextBox.Text;

            // valid price input to be decimal
            if (decimal.TryParse(priceTextBox.Text, out decimal price))
            {
                CellPhone phone = CreateCellPhone(brand, model, price);
                brandLabel.Text = phone.Brand;
                modelLabel.Text = phone.Model;
                priceLabel.Text = phone.Price.ToString("c2");
            }
            else
            {
                // display error message
                MessageBox.Show("Please enter a number value");
                priceTextBox.Focus();
                priceTextBox.BackColor = Color.Red;
            }
         


        }
    }
}
