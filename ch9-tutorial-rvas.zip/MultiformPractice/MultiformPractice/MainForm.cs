﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/23/2020
 * This program calls a form class
 */

namespace MultiformPractice
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnDisplayForm_Click(object sender, EventArgs e)
        {
            // create a message form class and show the message dialog
            MessageForm myMessageForm = new MessageForm();
            myMessageForm.ShowDialog();
        }
    }
}
