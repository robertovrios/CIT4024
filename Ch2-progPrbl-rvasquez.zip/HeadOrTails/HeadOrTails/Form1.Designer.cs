﻿namespace HeadOrTails
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnShowHead = new System.Windows.Forms.Button();
            this.btnShowTail = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.picBoxTail = new System.Windows.Forms.PictureBox();
            this.picBoxHead = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTail)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHead)).BeginInit();
            this.SuspendLayout();
            // 
            // btnShowHead
            // 
            this.btnShowHead.Location = new System.Drawing.Point(114, 229);
            this.btnShowHead.Name = "btnShowHead";
            this.btnShowHead.Size = new System.Drawing.Size(115, 64);
            this.btnShowHead.TabIndex = 2;
            this.btnShowHead.Text = "Show Heads";
            this.btnShowHead.UseVisualStyleBackColor = true;
            this.btnShowHead.Click += new System.EventHandler(this.btnShowHead_Click);
            // 
            // btnShowTail
            // 
            this.btnShowTail.Location = new System.Drawing.Point(321, 229);
            this.btnShowTail.Name = "btnShowTail";
            this.btnShowTail.Size = new System.Drawing.Size(115, 64);
            this.btnShowTail.TabIndex = 3;
            this.btnShowTail.Text = "Show Tails";
            this.btnShowTail.UseVisualStyleBackColor = true;
            this.btnShowTail.Click += new System.EventHandler(this.btnShowTail_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(546, 229);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(115, 64);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // picBoxTail
            // 
            this.picBoxTail.Image = global::HeadOrTails.Properties.Resources.Tails1;
            this.picBoxTail.Location = new System.Drawing.Point(292, 58);
            this.picBoxTail.Name = "picBoxTail";
            this.picBoxTail.Size = new System.Drawing.Size(158, 139);
            this.picBoxTail.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxTail.TabIndex = 1;
            this.picBoxTail.TabStop = false;
            this.picBoxTail.Visible = false;
            // 
            // picBoxHead
            // 
            this.picBoxHead.Image = global::HeadOrTails.Properties.Resources.Heads1;
            this.picBoxHead.Location = new System.Drawing.Point(292, 58);
            this.picBoxHead.Name = "picBoxHead";
            this.picBoxHead.Size = new System.Drawing.Size(158, 139);
            this.picBoxHead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxHead.TabIndex = 0;
            this.picBoxHead.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(767, 366);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnShowTail);
            this.Controls.Add(this.btnShowHead);
            this.Controls.Add(this.picBoxTail);
            this.Controls.Add(this.picBoxHead);
            this.Name = "Form1";
            this.Text = "Heads and Tails";
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTail)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxHead)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picBoxHead;
        private System.Windows.Forms.PictureBox picBoxTail;
        private System.Windows.Forms.Button btnShowHead;
        private System.Windows.Forms.Button btnShowTail;
        private System.Windows.Forms.Button btnExit;
    }
}

