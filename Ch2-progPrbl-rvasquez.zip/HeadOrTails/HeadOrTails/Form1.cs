﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 1/21/2020
 * This program shows heads or tails that the user 
 * choose when he/she click on the corresponding button
 */
namespace HeadOrTails
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowHead_Click(object sender, EventArgs e)
        {
            picBoxHead.Visible = true;
            picBoxTail.Visible = false;
        }

        private void btnShowTail_Click(object sender, EventArgs e)
        {
            picBoxHead.Visible = false;
            picBoxTail.Visible = true;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
