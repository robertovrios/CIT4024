﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 1/21/2020 
 * This program displays a setup and punch line message into the label object lblJoke
 */

namespace JokeAndPunchLine
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSetup_Click(object sender, EventArgs e)
        {
            lblJoke.Text = "Where would you find an elephant?";
        }

        private void btnPunchLine_Click(object sender, EventArgs e)
        {
            lblJoke.Text = "The same place you lost her";
        }
    }
}
