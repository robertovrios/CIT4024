﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PreferredCustomer
{
    class Customer: Person
    {
        //private int _phoneNumber;
        private bool _mailList;
        private int _customerNumber;
        private decimal _amountPurchase;
       


       // public int PhoneNumber { get {return _phoneNumber; } set { _phoneNumber = value; } }
        public bool MailList { get { return _mailList; } set { _mailList=value; } }
        public int CustomerNumber { get { return _customerNumber; } set { _customerNumber = value; } }
        public decimal AmountPurchase { get { return _amountPurchase; } set { _amountPurchase = value; } }

        public Customer()
        {
           // _phoneNumber = 0;
            _mailList = false;
            _customerNumber = 0;
            _amountPurchase = 0m;

        }

        public decimal Customer_Spends()
        {
            
            if (_amountPurchase >= 500 && _amountPurchase < 1000 ) _amountPurchase = _amountPurchase * (decimal)(1 - 0.05);
            if (_amountPurchase >= 1000 && _amountPurchase < 1500) _amountPurchase = _amountPurchase * (decimal)(1 - 0.06);
            if (_amountPurchase >= 1500 && _amountPurchase < 2000) _amountPurchase = _amountPurchase * (decimal)(1 - 0.07);
            if (_amountPurchase >= 2000 ) _amountPurchase = _amountPurchase * (decimal)(1 - 0.1);
            return _amountPurchase;
        }

    }
}
