﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/28/2020
 * This program shows the data of a customer and his/her expenses
 */

namespace PreferredCustomer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void displayButton_Click(object sender, EventArgs e)
        {
            // create a instance of customer and form classes
            Customer cliente = new Customer();
            Results resultado = new Results();

            // store values into customer class
            cliente.Name = fullNameTextBox.Text;
            cliente.Address = addressTextBox.Text;
            cliente.MailList = mailingListRadio.Checked;
            if(decimal.TryParse(amountPurchasedTextBox.Text, out decimal salida)) cliente.AmountPurchase = salida;
            Random rand = new Random();
            cliente.CustomerNumber = rand.Next(100001, 999999);

            // prints data in the form class
            Display_Results(cliente, resultado);

            

        }
        // method that prints results
        private void Display_Results(Customer cliente, Results resultado)
        {
            resultado.lblClientNumber.Text = cliente.CustomerNumber.ToString();
            resultado.lblName.Text = cliente.Name;
            resultado.lblAddress.Text = cliente.Address;
            resultado.lblAmountPurchase.Text = cliente.Customer_Spends().ToString("n2");
            resultado.lblMailList.Text = (cliente.MailList).ToString();
            resultado.ShowDialog();

        }
    }
}
