﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// child class
namespace EmployeeProdWorker
{
    class ProductionWorker:Employee
    {
        // properties
        private int _shift_number; // 1 is day and 2 is night
        private decimal _hourly_pay_rate;

        // constructor
        public ProductionWorker()
        {
            _shift_number = 0;
            _hourly_pay_rate = 0;
        }

        // properties
        public int Shift_number { get { return _shift_number; } set { _shift_number = value; } }
        public decimal Hourly_pay_rate { get { return _hourly_pay_rate; } set { _hourly_pay_rate = value; } }

        public string Day_OrNight()
        {
            string salida=null;
            if (Shift_number == 1)
            {
                salida = "Day";
            }else if(Shift_number==2)
            {
                salida = "Night";
            }
            else
            {
                salida = null;
            }
            return salida;
        }
    }
}
