﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// parent class Employee

namespace EmployeeProdWorker
{
    class Employee
    {
        private string _employee_name;
        private int _employee_number; // the exercises does not say nothing that employee is string or int... i prefer a number
        //contructor
        public Employee(string name, int number)
        {
            _employee_name = name;
            _employee_number = number;
        }

        // contructor 2
        public Employee()
        {
            _employee_name = null;
            _employee_number = 0;
        }

        // properties
        public string EmployeeName { get { return _employee_name; }   set{ _employee_name = value; } }
        public int EmployeeNumber { get { return _employee_number; } set { _employee_number = value; } }

    }
}
