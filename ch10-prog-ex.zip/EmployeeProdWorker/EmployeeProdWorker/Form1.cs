﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/28/2020
 * This program storages data into a class and show them in some labels
 */

namespace EmployeeProdWorker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCreateObject_Click(object sender, EventArgs e)
        {
            // create a class
            ProductionWorker prodWorker = new ProductionWorker();

            // setter on class
            prodWorker.EmployeeName = txtEmployeeName.Text;
            if (int.TryParse(txtEmployeeNumber.Text, out int salida)) prodWorker.EmployeeNumber = salida;
                else MessageBox.Show("Enter a valid employee number");
            if (decimal.TryParse(txtHourlyPayRate.Text, out decimal val)) prodWorker.Hourly_pay_rate = val;
                else MessageBox.Show("Enter a valid pay rate");

            // set the day or night shift
            if (rbDayShift.Checked)
            {
                prodWorker.Shift_number = 1;
            }else if(rbNightShift.Checked){
                prodWorker.Shift_number = 2;
            }
            else
            {
                prodWorker.Shift_number = 0;
            }

            // call the method to print all values
            displayValues(prodWorker);
        }

        // method that displays all class values
        private void displayValues(ProductionWorker prodWorker)
        {
            lblEmployeeName.Text = prodWorker.EmployeeName;
            lblEmployeeNumber.Text = prodWorker.EmployeeNumber.ToString();
            lblHourlyPayRate.Text = prodWorker.Hourly_pay_rate.ToString("n2");
            lblShift.Text = prodWorker.Day_OrNight();
        }
    }
}
