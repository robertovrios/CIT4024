﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/13/2020
 * This program uses 3 classes to demostrate polymorphism in classes
 */

namespace Polymorphism
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method that shows class info
        private void ShowAnimalInfo(Animal animal)
        {
            MessageBox.Show("Species: " + animal.Species);
            animal.MakeSound();

        }

        private void createAnimalButton_Click(object sender, EventArgs e)
        {
            // create a class Animal
            Animal animal = new Animal("Regular Animal");
            ShowAnimalInfo(animal);
        }

        private void createDogButton_Click(object sender, EventArgs e)
        {
            // create a class Dog
            Dog dog = new Dog("Chester");
            MessageBox.Show("The dog's name is: " + dog.Name);
            ShowAnimalInfo(dog);
        }

        private void createCatButton_Click(object sender, EventArgs e)
        {
            // create a class cat
            Cat cat = new Cat("Minino");
            MessageBox.Show("The cat's name is: " + cat.Name);
            ShowAnimalInfo(cat);
        }
    }
}
