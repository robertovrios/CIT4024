﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Threading.Tasks;

/* Roberto Vasquez
 * 2/24/2020
 * This program creates 2 classes to save and display data
 */

namespace CD_Account_Test
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method to set Account class values
        private void GetCDAccount(CDAccount account)
        {
            account.AccountNumber = accountNumberTextBox.Text;
            account.MaturityDate = maturityDateTextBox.Text;

            // test if the input data is decimal
            if (decimal.TryParse(interestRateTextBox.Text, out decimal interestRate))
            {
                account.InterestRate = interestRate;

                // test if the input data is decimal
                if (decimal.TryParse(balanceTextBox.Text, out decimal balance))
                    account.Balance = balance;
                // show error message
                else MessageBox.Show("Invalid Interest Balance");

            }
            else
                // show error message
                MessageBox.Show("Invalid Interest Rate");

        }

        private void createObjectButton_Click(object sender, EventArgs e)
        {
            // create an instance of the CDAccount class
            CDAccount account = new CDAccount();

            // set the values for account members 
            GetCDAccount(account);

            // get the values for the class account
            accountNumberLabel.Text = account.AccountNumber;
            interestRateLabel.Text = account.InterestRate.ToString("n2");
            balanceLabel.Text = account.Balance.ToString("c2");
            maturityDateLabel.Text = account.MaturityDate;


        }
    }
}
