﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program shows a temperature conversion table from celsius to fahrenheit*/

namespace CelsiusToFahrenheitTable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // add all the lines to the listbox
            for(int celsius = 0; celsius <= 20; celsius++)
            {
                lboxResults.Items.Add(celsius.ToString("n2")+ " Celsius is equivalent to "+ (((double)9 / 5) * celsius + 32).ToString("n2")+" Fahrenheit.");
            }
        }
    }
}
