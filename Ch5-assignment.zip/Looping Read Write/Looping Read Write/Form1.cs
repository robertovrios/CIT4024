﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program creates, reads from, and writes on a text file 
 */

namespace Looping_Read_Write
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnWriteOdd_Click(object sender, EventArgs e)
        {
            try
            {
                // clear the list box 
                lboxResults.Items.Clear();

                // show a dialog window to save a text file
                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    // create a text file
                    StreamWriter outFile= File.CreateText(saveDialog.FileName);

                    // write odd numbers in the tex file
                    for (int i = 1; i <= 100; i += 2)
                    {
                        outFile.WriteLine(i);
                        
                    }
                    outFile.Close();

                    // show the results
                    lblResults.Text = "File Write Complete";
                }
                else 
                {
                    MessageBox.Show("Operation Cancelled");
                }
            }catch(Exception ex)
            {
                MessageBox.Show("ex.Message");
            }
        }

        private void btnWriteEven_Click(object sender, EventArgs e)
        {
            try
            {
                // clear the list box 
                lboxResults.Items.Clear();

                // show a dialog window to save a text file
                if (saveDialog.ShowDialog() == DialogResult.OK)
                {
                    // create a output file
                    StreamWriter outFile = File.CreateText(saveDialog.FileName);
                    
                    // write odd numbers in the tex file
                    for (int i = 2; i <= 100; i += 2)
                    {
                        outFile.WriteLine(i);

                    }
                    outFile.Close();

                    // show the results
                    lblResults.Text = "File Write Complete";
                }
                else
                {
                    MessageBox.Show("Operation Cancelled");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ex.Message");
            }
        }

        private void btnReadFile_Click(object sender, EventArgs e)
        {
            try
            {
                // clear the list box 
                lboxResults.Items.Clear();

                // show a dialog window to open a text file
                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    // open a input file 
                    StreamReader inputFile= File.OpenText(openFile.FileName);

                    // write line by line the content of the file until end of file
                    while (!inputFile.EndOfStream)
                    {
                       lboxResults.Items.Add(inputFile.ReadLine().ToString());
                    }
                    inputFile.Close();
                    
                    // show results
                    lblResults.Text = "File Read Complete";
                }
                else
                {
                    MessageBox.Show("Operation Cancelled");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("ex.Message");
            }
        }
    }
}
