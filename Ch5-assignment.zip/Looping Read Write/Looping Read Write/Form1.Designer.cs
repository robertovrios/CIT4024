﻿namespace Looping_Read_Write
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnWriteOdd = new System.Windows.Forms.Button();
            this.btnWriteEven = new System.Windows.Forms.Button();
            this.btnReadFile = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblResults = new System.Windows.Forms.Label();
            this.lboxResults = new System.Windows.Forms.ListBox();
            this.saveDialog = new System.Windows.Forms.SaveFileDialog();
            this.openFile = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // btnWriteOdd
            // 
            this.btnWriteOdd.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWriteOdd.Location = new System.Drawing.Point(53, 52);
            this.btnWriteOdd.Name = "btnWriteOdd";
            this.btnWriteOdd.Size = new System.Drawing.Size(155, 101);
            this.btnWriteOdd.TabIndex = 0;
            this.btnWriteOdd.Text = "Write Odd Numbers";
            this.btnWriteOdd.UseVisualStyleBackColor = true;
            this.btnWriteOdd.Click += new System.EventHandler(this.btnWriteOdd_Click);
            // 
            // btnWriteEven
            // 
            this.btnWriteEven.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWriteEven.Location = new System.Drawing.Point(241, 52);
            this.btnWriteEven.Name = "btnWriteEven";
            this.btnWriteEven.Size = new System.Drawing.Size(155, 101);
            this.btnWriteEven.TabIndex = 1;
            this.btnWriteEven.Text = "Write Even Numbers";
            this.btnWriteEven.UseVisualStyleBackColor = true;
            this.btnWriteEven.Click += new System.EventHandler(this.btnWriteEven_Click);
            // 
            // btnReadFile
            // 
            this.btnReadFile.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReadFile.Location = new System.Drawing.Point(429, 52);
            this.btnReadFile.Name = "btnReadFile";
            this.btnReadFile.Size = new System.Drawing.Size(155, 101);
            this.btnReadFile.TabIndex = 2;
            this.btnReadFile.Text = "Read File";
            this.btnReadFile.UseVisualStyleBackColor = true;
            this.btnReadFile.Click += new System.EventHandler(this.btnReadFile_Click);
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(617, 52);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(155, 101);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblResults
            // 
            this.lblResults.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResults.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResults.Location = new System.Drawing.Point(130, 178);
            this.lblResults.Name = "lblResults";
            this.lblResults.Size = new System.Drawing.Size(545, 53);
            this.lblResults.TabIndex = 4;
            this.lblResults.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lboxResults
            // 
            this.lboxResults.FormattingEnabled = true;
            this.lboxResults.ItemHeight = 20;
            this.lboxResults.Location = new System.Drawing.Point(71, 255);
            this.lboxResults.Name = "lboxResults";
            this.lboxResults.Size = new System.Drawing.Size(687, 284);
            this.lboxResults.TabIndex = 5;
            // 
            // openFile
            // 
            this.openFile.FileName = "openFileDialog1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(830, 563);
            this.Controls.Add(this.lboxResults);
            this.Controls.Add(this.lblResults);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnReadFile);
            this.Controls.Add(this.btnWriteEven);
            this.Controls.Add(this.btnWriteOdd);
            this.Name = "Form1";
            this.Text = "Looping Read Write ";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnWriteOdd;
        private System.Windows.Forms.Button btnWriteEven;
        private System.Windows.Forms.Button btnReadFile;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblResults;
        private System.Windows.Forms.ListBox lboxResults;
        private System.Windows.Forms.SaveFileDialog saveDialog;
        private System.Windows.Forms.OpenFileDialog openFile;
    }
}

