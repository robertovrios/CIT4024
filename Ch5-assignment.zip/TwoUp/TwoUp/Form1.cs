﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program is a play to guess the value of two coins. User wins when he guess both coins values.
 */

namespace TwoUp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSpin_Click(object sender, EventArgs e)
        {
            // declare a random variable
            Random rand = new Random();

            // user has to make a guess first
            if (rbObverse.Checked || rbReverse.Checked || rbEwan.Checked)
            {
                // create 2 variables with random number between 0 (tail) and 1 (head)
                int coin1 = rand.Next(2);
                int coin2 = rand.Next(2);

                // shows the coin images according with the random value (0 or 1)
                if (coin1==1) // head
                {
                    picBoxCoin1.Image = Image.FromFile("../../images/Heads2.bmp");
                } else // tail
                {
                    picBoxCoin1.Image = Image.FromFile("../../images/Tails2.bmp");
                }
                if (coin2 == 1)// head
                {
                    picBoxCoin2.Image = Image.FromFile("../../images/Heads2.bmp");
                }
                else // tail
                {
                    picBoxCoin2.Image = Image.FromFile("../../images/Tails2.bmp");
                }

                // evaluate if the use wins checking player guess and game rules
                if (rbObverse.Checked && coin1 ==1 && coin2==1)
                {
                    lblResults.Text = "Obverse - You Win";
                }else if(rbReverse.Checked && coin1==0 && coin2==0)
                {
                    lblResults.Text = "Reverse - You Win";
                }else if(rbEwan.Checked && ((coin1 == 0 && coin2 == 1) || (coin1 == 1 && coin2 == 0)))
                {
                    lblResults.Text = "Ewan - You Win";
                }
                else
                {
                    lblResults.Text = "You Lose";
                }
                
            }
            else
            {
                MessageBox.Show("You need to Guess First!!");
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // clean all objects
            lblResults.Text = "";
            rbObverse.Checked = false;
            rbReverse.Checked = false;
            rbEwan.Checked = false;
            picBoxCoin1.Image = null;
            picBoxCoin2.Image = null;

        }


    }
}
