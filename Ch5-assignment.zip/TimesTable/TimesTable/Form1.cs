﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program creates a multipication table from  1 to 10
 */

namespace TimesTable
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // create 1 nested for loop to multiply their values
            for (int i = 1; i < 11; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    // multiply i*j
                    lblResult.Text+=(i*j).ToString("D2")+" ";
                }
                // show results
                lblResult.Text += "\n";
            }
        }
    }
}
