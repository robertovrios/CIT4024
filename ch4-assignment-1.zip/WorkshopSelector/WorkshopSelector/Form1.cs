﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Collections;


/* Roberto Vasquez
 * 2/4/2020
 * This program calculates the registration, lodging, and total cost from a list of courses and locations
 */
namespace WorkshopSelector
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // declare and initialize variables
            decimal registration_cost = 0;
            decimal lodging_fee = 0;
            // double total=0;
            int lodging_days = 0;
            lblResults.BackColor = Color.White;

            // control any exception
            try
            {
                // test that users choose both list options
                if (this.listWorkshop.SelectedIndex != -1 && this.listLocation.SelectedIndex != -1)
                {
                    // assign the right value according with user choice
                    switch (listWorkshop.SelectedItem.ToString())
                    {
                        case "Handling Stress":
                            registration_cost = 1000;
                            lodging_days = 3;
                            break;
                        case "Time Management":
                            registration_cost = 800;
                            lodging_days = 3;
                            break;
                        case "Supervision Skills":
                            registration_cost = 1500;
                            lodging_days = 3;
                            break;
                        case "Negotiation":
                            registration_cost = 1300;
                            lodging_days = 5;
                            break;
                        case "How to Interview":
                            registration_cost = 500;
                            lodging_days = 1;
                            break;
                        default:
                            break;
                    }

                    // assign the right value according with user choice
                    switch (listLocation.SelectedItem.ToString())
                    {
                        case "Austin":
                            lodging_fee = 150;

                            break;
                        case "Chicago":
                            lodging_fee = 225;
                            break;
                        case "Dallas":
                            lodging_fee = 175;
                            break;
                        case "Orlando":
                            lodging_fee = 300;
                            break;
                        case "Phoenix":
                            lodging_fee = 175;
                            break;
                        case "Raleigh":
                            lodging_fee = 150;
                            break;
                        default:
                            break;
                    }

                    // display results
                    lblResults.Text = "Registration: " + registration_cost.ToString("n2") + "\n" + "Lodging: " +
                                        lodging_fee + " x " + lodging_days + " = " + (lodging_fee * lodging_days).ToString("n2") 
                                        + "\n" + "Total: " + (registration_cost + lodging_fee * lodging_days).ToString("n2");

                }
                else
                {
                    // show errors
                    lblResults.Text = "Please choose both options!!!";
                    lblResults.BackColor = Color.Pink;

                }
            } catch(Exception ex)
            {
                // show exception
                MessageBox.Show(ex.Message);
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
