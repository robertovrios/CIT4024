﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



/* Roberto Vasquez
 * 2/4/2020
 * This program receives 4 number of coins, adds them, and decides if they are below, equal, or above 1 dollar.
 */

namespace ChangeDollars
{
    public partial class Form1 : Form
    {
        // create 4 decimal constants 
        const decimal PENNY = 0.01m;
        const decimal NICKEL= 0.05m;
        const decimal DIME = 0.10m;
        const decimal QUARTER = 0.25m;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {

            try
            {
                // create 4 variables 
                int pennies = int.Parse(txtPenny.Text);
                int nickels = int.Parse(txtNickel.Text);
                int dimes = int.Parse(txtDime.Text);
                int quarters = int.Parse(txtQuarter.Text);

                // test that the variables must be greater and equal than zero

                if (pennies >= 0 && nickels >= 0 && dimes >= 0 && quarters >= 0)
                {
                    // calculate the total amount
                    decimal total = pennies * PENNY + nickels * NICKEL + dimes * DIME + quarters * QUARTER;

                    // test if the total amount is equal, less or more than 1 dollar.
                    if (total == 1)
                    {
                        lblResults.Text = "Great, you have 1 dollar in total.";
                        lblResults.BackColor = Color.LightGreen;
                        lblResults.Font = new Font(this.Font, FontStyle.Bold);

                    }
                    else if (total > 1)
                    {
                        lblResults.Text = "Sorry but you have more than 1 dollar.";
                        lblResults.BackColor = Color.LightPink;
                        lblResults.Font = new Font(this.Font, FontStyle.Bold);
                    }
                    else
                    {
                        lblResults.Text = "Sorry but you have less than 1 dollar.";
                        lblResults.BackColor = Color.LightPink;
                        lblResults.Font = new Font(this.Font, FontStyle.Bold);
                    }
                }
                else
                {
                    lblResults.Text = "Please enter only positive values.";
                    lblResults.BackColor = Color.LightPink;
                    //lblResults.Font = new Font(lblResults.Font, FontStyle.Bold);
                    lblResults.Font = new Font(this.Font, FontStyle.Bold);
                }
            }
            catch(Exception ex)
            {
                //MessageBox.Show(ex.Message);
                lblResults.Text = ex.Message;
                lblResults.BackColor = Color.LightPink;
                lblResults.Font = new Font(this.Font, FontStyle.Bold);
            }
        }
    }
}
