﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



/* Roberto Vasquez
 * 2/4/2020
 * This program calculates the weight of the object and evaluate its value
 */

namespace MassWeight
{
    public partial class Form1 : Form
    {
        const double NEWTON_CONST = 9.8;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            double mass;
            // valid the input number greater and equal to zero
            if (double.TryParse(txtMass.Text, out mass) && mass>=0)
            {
                // test if the value is greater than 10
                if (mass * NEWTON_CONST > 10)
                {
                    lblResults.Text = "The object is too heavy.";
                    lblResults.Font = new Font(this.Font, FontStyle.Bold);
                }
                else
                {
                    lblResults.Text = "The object is too light.";
                    lblResults.Font = new Font(this.Font, FontStyle.Bold);
                }
            }
            else
            {
                lblResults.Text = "Please enter a positive number";
                lblResults.BackColor = Color.Pink;
                lblResults.Font = new Font(this.Font, FontStyle.Bold);
            }
        }
    }
}
