﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;



/* Roberto Vasquez
 * 2/4/2020
 * This program changes the color of the form background
 */

namespace ColorMixer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnMix_Click(object sender, EventArgs e)
        {
            // verify that a list box has been selected 
            if ((rbRed1.Checked || rbBlue1.Checked || rbYellow1.Checked) && (rbRed2.Checked || rbBlue2.Checked ||  rbYellow2.Checked))
            {
                if (rbRed1.Checked && rbRed2.Checked)
                {
                    this.BackColor = Color.Red;
                } else if(rbBlue1.Checked && rbBlue2.Checked)
                {
                    this.BackColor = Color.Blue;

                }else if(rbYellow1.Checked && rbYellow2.Checked)
                {
                    this.BackColor = Color.Yellow;
                }
                else if (rbRed1.Checked && rbBlue2.Checked || rbRed2.Checked && rbBlue1.Checked)
                {
                    this.BackColor = Color.Purple;
                }
                else if(rbRed1.Checked && rbYellow2.Checked || rbRed2.Checked && rbYellow1.Checked)
                {
                    this.BackColor = Color.Orange;
                }
                else if (rbBlue1.Checked && rbYellow2.Checked || rbBlue2.Checked && rbYellow1.Checked)
                {
                    this.BackColor = Color.Green;
                }

            }
            else
            {
                MessageBox.Show("Please select both colors colors!!!");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
