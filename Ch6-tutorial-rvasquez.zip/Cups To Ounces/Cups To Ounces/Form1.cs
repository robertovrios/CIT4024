﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program converts cups in ounces 
 */

namespace Cups_To_Ounces
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // method to convert cups in ounces
        private double ConvertCupsToOunces(double cantidad)
        {
            return cantidad * 8;
        } 
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void convertButton_Click(object sender, EventArgs e)
        {
            // clean the objects
            ouncesLabel.Text = null;
            cupsTextBox.BackColor = Color.White;

            //declare a variable cantidad
            double cantidad;

            // valid the input data
            if (double.TryParse(cupsTextBox.Text, out cantidad))
            {
                // data must be greater and equal than 0
                if (cantidad >= 0)
                {
                    ouncesLabel.Text = ConvertCupsToOunces(cantidad).ToString("n2");
                }
                else
                {
                    // show error
                    ShowErrors(2);
                }
            }
            else
            {
                // show error
                ShowErrors(1);
            }
        }

        // method to show errors
        private void ShowErrors(int errorCode)
        {
            cupsTextBox.BackColor = Color.Pink;
            cupsTextBox.Focus();
            
            switch (errorCode)
            {
                case 1:
                    MessageBox.Show("Please enter a valid input!");
                    break;
                case 2:
                    MessageBox.Show("Enter a positive value!");
                    break;
                default:
                    MessageBox.Show("Unknown error!");
                    break;
            }
        }
    }
}
