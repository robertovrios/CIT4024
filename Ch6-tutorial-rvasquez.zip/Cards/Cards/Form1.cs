﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program plays with cards and shows a choosen card for the user
 */

namespace Cards
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnShowCard_Click(object sender, EventArgs e)
        {
            // test if the user choose a card
            if (lboxCard.SelectedIndex != -1)
            {
                // call the method to evaluate the card choosen for the user
                ShowCard(lboxCard.SelectedItem.ToString());
            }
            else
            {
                MessageBox.Show("Please choose a card!!!");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method that evaluates the card 
        private void ShowCard(string card)
        {
            // compare the value of the card and call the linked method 
            switch (card)
            {
                case "Ace of Spades":
                    ShowAceofSpades();
                    break;
                case "10 of Hearts":
                    ShowTenHearts();
                    break;
                case "King of Clubs":
                    ShowKingClubs();
                    break;
                default:
                    break;
            }

        }

        // show Ace of Spades card
        private void ShowAceofSpades()
        {
            picBoxAceSpades.Visible = true;
            picBoxTenHearts.Visible = false;
            picBoxKingClubs.Visible = false;
        }

        // show Ten of Hearts card
        private void ShowTenHearts()
        {
            picBoxAceSpades.Visible = false;
            picBoxTenHearts.Visible = true;
            picBoxKingClubs.Visible = false;
        }

        // show king of clubs card
        private void ShowKingClubs()
        {
            picBoxAceSpades.Visible = false;
            picBoxTenHearts.Visible = false;
            picBoxKingClubs.Visible = true;
        }

        // make the cards not visible for the user
        private void Form1_Load(object sender, EventArgs e)
        {
            picBoxAceSpades.Visible = false;
            picBoxTenHearts.Visible = false;
            picBoxKingClubs.Visible = false;
        }
    }
}
