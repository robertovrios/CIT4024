﻿namespace Cards
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.picBoxAceSpades = new System.Windows.Forms.PictureBox();
            this.picBoxTenHearts = new System.Windows.Forms.PictureBox();
            this.picBoxKingClubs = new System.Windows.Forms.PictureBox();
            this.btnShowCard = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lboxCard = new System.Windows.Forms.ListBox();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAceSpades)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTenHearts)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKingClubs)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.picBoxKingClubs);
            this.groupBox1.Controls.Add(this.picBoxTenHearts);
            this.groupBox1.Controls.Add(this.picBoxAceSpades);
            this.groupBox1.Location = new System.Drawing.Point(44, 56);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(575, 275);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            // 
            // picBoxAceSpades
            // 
            this.picBoxAceSpades.Image = global::Cards.Properties.Resources.Ace_Spades;
            this.picBoxAceSpades.Location = new System.Drawing.Point(26, 31);
            this.picBoxAceSpades.Name = "picBoxAceSpades";
            this.picBoxAceSpades.Size = new System.Drawing.Size(156, 198);
            this.picBoxAceSpades.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxAceSpades.TabIndex = 0;
            this.picBoxAceSpades.TabStop = false;
            // 
            // picBoxTenHearts
            // 
            this.picBoxTenHearts.Image = global::Cards.Properties.Resources._10_Hearts;
            this.picBoxTenHearts.Location = new System.Drawing.Point(209, 31);
            this.picBoxTenHearts.Name = "picBoxTenHearts";
            this.picBoxTenHearts.Size = new System.Drawing.Size(156, 198);
            this.picBoxTenHearts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxTenHearts.TabIndex = 1;
            this.picBoxTenHearts.TabStop = false;
            // 
            // picBoxKingClubs
            // 
            this.picBoxKingClubs.Image = global::Cards.Properties.Resources.King_Clubs;
            this.picBoxKingClubs.Location = new System.Drawing.Point(392, 31);
            this.picBoxKingClubs.Name = "picBoxKingClubs";
            this.picBoxKingClubs.Size = new System.Drawing.Size(156, 198);
            this.picBoxKingClubs.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.picBoxKingClubs.TabIndex = 2;
            this.picBoxKingClubs.TabStop = false;
            // 
            // btnShowCard
            // 
            this.btnShowCard.Location = new System.Drawing.Point(134, 520);
            this.btnShowCard.Name = "btnShowCard";
            this.btnShowCard.Size = new System.Drawing.Size(103, 50);
            this.btnShowCard.TabIndex = 1;
            this.btnShowCard.Text = "S&how Card";
            this.btnShowCard.UseVisualStyleBackColor = true;
            this.btnShowCard.Click += new System.EventHandler(this.btnShowCard_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(390, 520);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(103, 50);
            this.btnExit.TabIndex = 2;
            this.btnExit.Text = "E&xit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lboxCard
            // 
            this.lboxCard.FormattingEnabled = true;
            this.lboxCard.ItemHeight = 20;
            this.lboxCard.Items.AddRange(new object[] {
            "Ace of Spades",
            "10 of Hearts",
            "King of Clubs"});
            this.lboxCard.Location = new System.Drawing.Point(240, 366);
            this.lboxCard.Name = "lboxCard";
            this.lboxCard.Size = new System.Drawing.Size(159, 124);
            this.lboxCard.TabIndex = 3;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 618);
            this.Controls.Add(this.lboxCard);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnShowCard);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Cards";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picBoxAceSpades)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxTenHearts)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBoxKingClubs)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox picBoxKingClubs;
        private System.Windows.Forms.PictureBox picBoxTenHearts;
        private System.Windows.Forms.PictureBox picBoxAceSpades;
        private System.Windows.Forms.Button btnShowCard;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.ListBox lboxCard;
    }
}

