﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/12/2020
 * This program turns on and off a light.
 */

namespace Lights
{
    public partial class Form1 : Form
    {
        // define string constants
        const string varOff = "OFF";
        const string varOn = "ON";
        public Form1()
        {
            InitializeComponent();
        }

        // when the user clicks on the button the light turns on or off depending of the current state
        private void btnSwitch_Click(object sender, EventArgs e)
        {
            if (lblResult.Text == varOff)
            {
                // call the TurnLightOn method
                TurnLightOn();
            }
            else if(lblResult.Text == varOn)
            {
                // call the TurnLightOff method
                TurnLightOff();
            }
            else
            {
                picBoxLight.Image = null;
                picBoxLight.Visible = true;
                lblResult.Text = null;
            }
        }

        // load the form with the lights off
        private void Form1_Load(object sender, EventArgs e)
        {
            picBoxLight.Image = Image.FromFile("../../images/LightOff.bmp");
            picBoxLight.Visible = true;
            lblResult.Text = varOff;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // method that shows the image of a light on
        private void TurnLightOn()
        {
            picBoxLight.Image = Image.FromFile("../../images/LightOn.bmp");
            picBoxLight.Visible = true;
            lblResult.Text = varOn;
        }

        // method that shows the image of a light off
        private void TurnLightOff()
        {
            picBoxLight.Image = Image.FromFile("../../images/LightOff.bmp");
            picBoxLight.Visible = true;
            lblResult.Text = varOff;
        }
    }
}
