﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

/* Roberto Vasquez
 * 2/12/2020
 * This program opens a file and shows its contents in a list box object
 */

namespace North_America
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // method to open a file a return its value
        private string GetFile()
        {
            string filename = null;
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                filename = openFile.FileName;
            }
            return filename;
        }

        // method to read a file and write its contents in a list box
        private void ReadFile(String fileName)
        {

            try
            {
                StreamReader inputFile = File.OpenText(fileName);
                while (!inputFile.EndOfStream)
                {
                    countriesListBox.Items.Add(inputFile.ReadLine());
                }
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }


        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }


        private void getCountriesButton_Click(object sender, EventArgs e)
        {
            // clean the list box
            countriesListBox.Items.Clear();

            // create a variable filename 
            string filename = GetFile();

            // if its value is not null so call the method ReadFile
            if (filename != null)
            {
                ReadFile(filename);
            }
            else // it never happens :)
            {
                MessageBox.Show("You need to choose a file first!");
            }
        }
    }
}
