﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


/* Roberto Vasquez
 * 2/1/2020
 * This program calculates the gross income that is the sum of base and overtime salaries.
 */


namespace PayrollWithOvertime
{
    public partial class Form1 : Form
    {
        // define the constants 
        const decimal BASE_HOURS = 40.0m;
        const decimal OT_MULTIPLIER = 1.5m;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // clear the contents of the text boxes
            txtHourlyPayRate.Text = "";
            txtHoursWorked.Text = "";
            lblGrossPay.Text = "";
            // focus on the first text box
            txtHoursWorked.Focus();
            // change the backcolor to white
            txtHourlyPayRate.BackColor = Color.White;
            txtHoursWorked.BackColor = Color.White;

        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // define variables 
            int i = 1;
            // change the backcolor of the text boxes to white
            txtHourlyPayRate.BackColor = Color.White;
            txtHoursWorked.BackColor = Color.White;

            try
            {
                // define and initialize variables
                decimal hoursWorked = decimal.Parse(txtHoursWorked.Text);
                i++;
                decimal hourlyPayRate = decimal.Parse(txtHourlyPayRate.Text);
                i++;

                decimal basePay = 0;
                decimal overtimePay = 0;
                decimal overtimeHours = 0;

                // validate that worked hours are positive and less than 40
                if (hoursWorked >=0 && hoursWorked <= 40 )
                {
                    basePay = hourlyPayRate * BASE_HOURS;
                }
                // validate that worked hours greater than 40
                else if (hoursWorked > 40)
                {
                    // calculate overtime hours
                    overtimeHours = (hoursWorked - 40);
                    // calculate overtime salary
                    overtimePay = overtimeHours * OT_MULTIPLIER * hourlyPayRate;

                }
                // show error message if the inputs are invalid
                else if (hoursWorked<0 || hourlyPayRate<0)
                {
                    MessageBox.Show("Please, enter positive numbers");
                }
                // calculate and display the gross salary 
                decimal grossPay = basePay + overtimePay;
                lblGrossPay.Text = grossPay.ToString();
            }catch (Exception ex)
            {
                //MessageBox.Show(ex.Message);
                // change and focus the text box when there's invalid data input. 
                switch (i)
                {
                    case 1:
                        txtHoursWorked.BackColor = Color.Red;
                        txtHoursWorked.Focus();
                        break;
                    case 2:
                        txtHourlyPayRate.BackColor = Color.Red;
                        txtHourlyPayRate.Focus();
                        break;
                    default:
                        break;
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
