﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/1/2020
 * This program calculates the miles per gallons that a car uses.
 */

namespace FuelEconomy
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // close the form
            this.Close();
        }

        private void btnCalculateMPG_Click(object sender, EventArgs e)
        {
            txtGallons.BackColor = Color.White;
            txtMiles.BackColor = Color.White;

            double miles; // to hold miles driven
            double gallons; // to hold gallons used
            double mpg; // to hold MPG

            // validate the milesTextBox control
            if (double.TryParse(txtMiles.Text, out miles))
            {
                if (double.TryParse(txtGallons.Text, out gallons))
                {
                    
                    // validate that the gallons greater than zero and miles greater than and equals to zero
                    if (gallons > 0 && miles >= 0)
                    {
                        // calculate MPG
                        mpg = miles / gallons;

                        // display the MPG in the mpgLabel control
                        lblMPG.Text = mpg.ToString("n1");
                    }
                    else
                    {
                        MessageBox.Show("Enter positive numbers.");
                        txtGallons.Focus();

                    }
                }
                else
                {
                    // Display an error message for gallons textbox
                    MessageBox.Show("Invalid input for gallons.");
                    txtGallons.BackColor = Color.Red;
                    txtGallons.Focus();

                }
            }
            else
            {
                // Display an error message for miles textbox
                MessageBox.Show("Invalid input for miles.");
                txtMiles.BackColor = Color.Red;
                txtMiles.Focus();
            }
        }
    }
}
   
