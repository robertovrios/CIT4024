﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 2/13/2020
 * This program shows 5 winner random numbers 
 */

namespace Lottery_Numbers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generateButton_Click(object sender, EventArgs e)
        {
            // create a random variable and an integer array of size 5
            Random r = new Random();
            int[] winnerNumbers = new int[5];

            // fill out the array with random numbers
            for(int i = 0; i < 5; i++)
            {
                winnerNumbers[i] = r.Next(100);
            }

            //show the winner numbers
            firstLabel.Text  = winnerNumbers[0].ToString();
            secondLabel.Text = winnerNumbers[1].ToString();
            thirdLabel.Text  = winnerNumbers[2].ToString(); 
            fourthLabel.Text = winnerNumbers[3].ToString(); 
            fifthLabel.Text  = winnerNumbers[4].ToString(); 

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
