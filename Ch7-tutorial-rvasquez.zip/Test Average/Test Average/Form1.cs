﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

/* Roberto Vasquez
 * 2/13/2020
 * This program opens a file and shows its contents in a list box object. Moreover, shows the highest, lowest, and average grades.
 */

namespace Test_Average
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // calculate the highest grade
        private int Highest(int[] iArray)
        {
            // declare a highest variable with the first value of the array
            int highest = iArray[0];

            // compare all the values in an array to get the highest value
            for (int i = 1; i < iArray.Length; i++)
            {
                if (highest < iArray[i])
                {
                    highest = iArray[i];
                }
            }
            return highest;
        }

        private int Lowest(int[] iArray)
        {
            // declare a lowest variable with the first value of the array
            int lowest = iArray[0];

            // compare all the values in an array to get the lowest value
            for (int i = 1; i < iArray.Length; i++)
            {
                if (lowest > iArray[i])
                {
                    lowest = iArray[i];
                }
            }
            return lowest;
        }

        private void getScoresButton_Click(object sender, EventArgs e)
        {
            // clena the labels and textbox
            cleanLabelsAndTexts();
            try
            {
                // get the file name from the method getFile
                string fileName = GetFile();
                // get the size from a method that count the lines in a file
                int[] grades = new int[LinesCounter(fileName)];
                int numero;

                // if the filename is not null open and read the file
                if (fileName != null)
                {
                    StreamReader inputFile = File.OpenText(fileName);
                    for (int i = 0; i < grades.Length; i++)
                    {
                        if (int.TryParse(inputFile.ReadLine(), out numero))
                        {
                            // assign the line to a variable
                            grades[i] = numero;
                            // show in the list box
                            testScoresListBox.Items.Add(numero);
                        }
                        else
                        {
                            // error if it is found a line that is not a integer
                            MessageBox.Show("There is a record in the file that is not integer!!!");
                            break;
                        }

                    }
                    inputFile.Close();

                    highScoreLabel.Text = Highest(grades).ToString();
                    lowScoreLabel.Text = Lowest(grades).ToString();

                    // not need to create an average method
                    averageScoreLabel.Text = grades.Average().ToString("n1");

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        // method to open a file a return its value
        private string GetFile()
        {
            string filename = null;
            if (openFile.ShowDialog() == DialogResult.OK)
            {
                filename = openFile.FileName;
            }
            else
            {
                MessageBox.Show("Please choose a file");
                GetFile();
            }
            return filename;
        }

        // method that cleans the labels and textbox
        private void cleanLabelsAndTexts()
        {
            testScoresListBox.Items.Clear();
            highScoreLabel.Text = null;
            lowScoreLabel.Text = null;
            averageScoreLabel.Text = null;

        }

        private int LinesCounter(string filename)
        {
            int count = 0;
            StreamReader file = new StreamReader(filename);
            while (file.ReadLine() != null)
            {
                count++;
            }
            return count;
        }
    }
}
