﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace TipTaxTotal
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                double meal = double.Parse(txtFoodCharge.Text);
                double tip = meal * 0.15;
                double tax = meal * 0.07;

                lblResult1.Text = tip.ToString("n2");
                lblResult2.Text = tax.ToString("n2");
                lblResult3.Text = (meal + tip + tax).ToString("n2");
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
