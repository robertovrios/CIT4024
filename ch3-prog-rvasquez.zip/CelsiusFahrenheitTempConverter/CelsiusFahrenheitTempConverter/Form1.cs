﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 1/29/2020
 * This program changes a temperature from Celsius to Fahrenheit and viceversa
 */

namespace CelsiusFahrenheitTempConverter
{

    public partial class Form1 : Form
    {
        //private double temp=0;
        public Form1()
        {
            InitializeComponent();

        }

        private void btnFtoC_Click(object sender, EventArgs e)
        {
            // temp = double.Parse(txtTemperature.Text);
            try
            {
                // print the temperature in celsius
                lblTemperatureOut.Text = ((5.0 / 9.0) * (double.Parse(txtTemperature.Text) - 32.0)).ToString();

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCtoF_Click(object sender, EventArgs e)
        {
            try
            {
                // temp = double.Parse(txtTemperature.Text);
                // print the temperature in fahrenheit
                lblTemperatureOut.Text = ((9.0 / 5.0) * (double.Parse(txtTemperature.Text) + 32.0)).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
