﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 1/29/2020
 * This program calculates the subtotal for each ticket 
 * class and a total for all tickets
 */

namespace StadiumSeating
{
    public partial class Form1 : Form
    {
        // define the constants as decimal types
        const decimal CLASS_A_COST = 15m;
        const decimal CLASS_B_COST = 12m;
        const decimal CLASS_C_COST = 9m;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            int i = 1;

            // change the backcolor to white
            txtClassA.BackColor = Color.White;
            txtClassB.BackColor = Color.White;
            txtClassC.BackColor = Color.White;

            try
            {
                // create decimal variables and assign the input values
                // the inputs must be integer 

                decimal classASub = int.Parse(txtClassA.Text) * CLASS_A_COST;
                i++;
                decimal classBSub = int.Parse(txtClassB.Text) * CLASS_B_COST;
                i++;
                decimal classCSub = int.Parse(txtClassC.Text) * CLASS_C_COST;
                i++;
                decimal total = classASub + classBSub + classCSub;

                // write the results on the results labels
                lblClassA.Text = classASub.ToString("n2");
                lblClassB.Text = classBSub.ToString("n2");
                lblClassC.Text = classCSub.ToString("n2");
                lblTotal.Text = total.ToString("n2");

            } catch(Exception ex)
            {
                //MessageBox.Show(ex.Message);
                // if there's any error, change the backcolor to red and focus on the object
                switch (i){
                    case 1:
                        txtClassA.BackColor = Color.Red;
                        txtClassA.Focus();
                        break;
                    case 2:
                        txtClassB.BackColor = Color.Red;
                        txtClassB.Focus();
                        break;
                    case 3:
                        txtClassC.BackColor = Color.Red;
                        txtClassC.Focus();
                        break;
                    default:
                        break;

                }

            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            // clean the textboxes and labels and focus on the 1st box
            txtClassA.Text = "";
            txtClassB.Text = "";
            txtClassC.Text = "";


            lblClassA.Text = "";
            lblClassB.Text = "";
            lblClassC.Text = "";
            lblTotal.Text = "";

            // change the backcolor to white
            txtClassA.BackColor = Color.White;
            txtClassB.BackColor = Color.White;
            txtClassC.BackColor = Color.White;

            txtClassA.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
