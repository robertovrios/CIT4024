﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

/* Roberto Vasquez
 * 1/29/2020
 * This program calculates the total based on the user inputs
 */

namespace AutomobileCosts
{
    public partial class Form1 : Form
    {
        double cost = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            // define local variables
            int i = 1;
            double loan;
            double insurance;
            double gas;
            double oil;
            double tires;
            double maintenance;
            try
            {
                // change to white all Textboxes
                ChangeToWhite();

                //double[] loanValues=new double[] { 1.0,1.0};

                // assign values to local variables
                loan = double.Parse(txtLoan.Text);
                i++;
                insurance = double.Parse(txtInsurance.Text);
                i++;
                gas =double.Parse(txtGas.Text);
                i++;
                oil = double.Parse(txtOil.Text);
                i++;
                tires =double.Parse(txtTires.Text);
                i++;
                maintenance =double.Parse(txtMaintenance.Text);
                i++;
                // calculate the total cost
                cost = loan + insurance + gas + oil + tires + maintenance;

                // print the results on the results label
                lblResults.Text = "Total Monthly Cost: " +
                    cost.ToString("n2") +
                    "\n" + "Total Annual Cost: " + (cost * 12).ToString("n2");
            }
            catch (Exception ex)
            {
                // MessageBox.Show(ex.Message);
                // change and focus where is an input error
                switch (i)
                {
                    case 1:
                        txtLoan.Focus();
                        txtLoan.BackColor = Color.Red;
                        break;
                    case 2:
                        txtInsurance.Focus();
                        txtInsurance.BackColor = Color.Red;
                        break;
                    case 3:
                        txtGas.Focus();
                        txtGas.BackColor = Color.Red;
                        break;
                    case 4:
                        txtOil.Focus();
                        txtOil.BackColor = Color.Red;
                        break;
                    case 5:
                        txtTires.Focus();
                        txtTires.BackColor = Color.Red;
                        break;
                    case 6:
                        txtMaintenance.Focus();
                        txtMaintenance.BackColor = Color.Red;
                        break;
                    default:
                        break;
                }

            }
        }
        public void ChangeToWhite()
        {
           // change the color of the textboxes
            txtLoan.BackColor = Color.White;
            txtInsurance.BackColor = Color.White;
            txtGas.BackColor = Color.White;
            txtOil.BackColor = Color.White;
            txtTires.BackColor = Color.White;
            txtMaintenance.BackColor = Color.White;
        }

    }
}
