﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


/* Roberto Vasquez
 * 3/3/2020
 * This program show all items from a table product and search items by description
 */


namespace ProductSearch
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void productBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.productBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.productDataSet);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'productDataSet.Product' table. You can move, or remove it, as needed.
            this.productTableAdapter.Fill(this.productDataSet.Product);

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            // call the search query using txtsearch value
            this.productTableAdapter.SearchDesc(this.productDataSet.Product, txtSearch.Text);
        }

        private void btnShowAll_Click(object sender, EventArgs e)
        {
            // fill the table with all items
            txtSearch.Text = null;
            this.productTableAdapter.Fill(this.productDataSet.Product);
        }
    }
}
